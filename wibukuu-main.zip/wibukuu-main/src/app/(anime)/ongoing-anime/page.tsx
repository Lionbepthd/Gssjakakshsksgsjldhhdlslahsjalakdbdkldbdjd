import ErrorSegment from "@/components/layout/error-segment";

export default function OngoingAnimePage() {
  return <ErrorSegment />;
}
