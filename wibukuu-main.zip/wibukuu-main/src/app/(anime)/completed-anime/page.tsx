import ErrorSegment from "@/components/layout/error-segment";

export default function CompletedAnimePage() {
  return <ErrorSegment />;
}
